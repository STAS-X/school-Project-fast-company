import Qualities from "./qualitiesList";
export default Qualities;
